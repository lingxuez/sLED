library(testthat)
library(sLED)

test_check("sLED")
